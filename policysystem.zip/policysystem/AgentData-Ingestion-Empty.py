# Databricks notebook source
# MAGIC %md
# MAGIC <span style="color:orange">
# MAGIC  <h2> Live Project Workshop By Deepak Goyal - Azurelib Academy
# MAGIC </span>
# MAGIC   <h5>
# MAGIC     <span style="color:red">
# MAGIC <b>Author: Deepak Goyal <br>
# MAGIC    <a href='https://ade.azurelib.com'> ade.azurelib.com </a><br>
# MAGIC    Email at: admin@azurelib.com
# MAGIC    <br><a href ="https://www.linkedin.com/in/deepak-goyal-93805a17/" > Deepak Goyal Linkedin </a>
# MAGIC </span>

# COMMAND ----------

# MAGIC %md
# MAGIC <b> Load the Agent data from landing folder to Dataframe with extra column 'merge_flag'. </b>
# MAGIC <br> Use the schema as: agent_id integer, agent_name string, agent_email string,agent_phone string, branch_id integer, create_timestamp timestamp
# MAGIC <br>
# MAGIC <b> Save it as Agent Table with location as bronzelayer/Agent

# COMMAND ----------

#Write your code here

# COMMAND ----------

# MAGIC %md
# MAGIC <b> Check if table is accessible and showing data

# COMMAND ----------

#Write your code here

# COMMAND ----------

# MAGIC %md
# MAGIC <b> Move the loaded file from landing folder to processed folder using the proper date-time column mm-dd-yyyy folder 

# COMMAND ----------

#Write your code here

# COMMAND ----------

# MAGIC %md
# MAGIC <b> Extension: You can add the test cases for all the steps

# COMMAND ----------

#Write your code here

# COMMAND ----------

# MAGIC %md
# MAGIC <b> For any help reach out here:
# MAGIC  <a href="https://adeus.azurelib.com"> adeus.azurelib.com </a><br>
# MAGIC    Email at: admin@azurelib.com
# MAGIC    <br> 
# MAGIC    <a href ="https://www.linkedin.com/in/deepak-goyal-93805a17/" > Message Deepak Goyal here on Linkedin </a>