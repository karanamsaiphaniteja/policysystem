# Databricks notebook source
#code for mounting
#dbutils.fs.mount( source = 'wasbs://<container_name>@<storage_account_name>.blob.core.windows.net', 
                 #mount_point= '<mount_point_name>', extra_configs ={'fs.azure.sas.<container_name>.<storage_account_name>.blob.core.windows.net':'<SAS-TOKEN>'})
#mounting bronzelayer

dbutils.fs.mount( source = 'wasbs://bronzelayer@policysystem.blob.core.windows.net', 
                 mount_point= '/mnt/bronzelayer', extra_configs ={'fs.azure.sas.bronzelayer.policysystem.blob.core.windows.net':'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2025-03-06T03:02:27Z&st=2025-03-04T19:02:27Z&spr=https&sig=Nh08v2aSh6AhwMY09K0J0isNn%2BqkZcMjezthOEwz9RQ%3D'})

# COMMAND ----------

#mounting landing

dbutils.fs.mount( source = 'wasbs://landing@policysystem.blob.core.windows.net', 
                 mount_point= '/mnt/landing', extra_configs ={'fs.azure.sas.landing.policysystem.blob.core.windows.net':'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2025-03-06T03:02:27Z&st=2025-03-04T19:02:27Z&spr=https&sig=Nh08v2aSh6AhwMY09K0J0isNn%2BqkZcMjezthOEwz9RQ%3D'})

# COMMAND ----------

#mounting processed
dbutils.fs.mount( source = 'wasbs://processed@policysystem.blob.core.windows.net', 
                 mount_point= '/mnt/processed', extra_configs ={'fs.azure.sas.processed.policysystem.blob.core.windows.net':'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2025-03-06T03:02:27Z&st=2025-03-04T19:02:27Z&spr=https&sig=Nh08v2aSh6AhwMY09K0J0isNn%2BqkZcMjezthOEwz9RQ%3D'})

# COMMAND ----------

#mounting silverlayer
dbutils.fs.mount( source = 'wasbs://silverlayer@policysystem.blob.core.windows.net', 
                 mount_point= '/mnt/silverlayer', extra_configs ={'fs.azure.sas.silverlayer.policysystem.blob.core.windows.net':'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2025-03-06T03:02:27Z&st=2025-03-04T19:02:27Z&spr=https&sig=Nh08v2aSh6AhwMY09K0J0isNn%2BqkZcMjezthOEwz9RQ%3D'})

# COMMAND ----------

mounts = dbutils.fs.mounts()
silverlayer_mount = [mount.mountPoint for mount in mounts if 'silverlayer' in mount.source][0]
silverlayer_mount

# COMMAND ----------

#mounting goldlayer
dbutils.fs.mount( source = 'wasbs://goldlayer@policysystem.blob.core.windows.net', 
                 mount_point= '/mnt/goldlayer', extra_configs ={'fs.azure.sas.goldlayer.policysystem.blob.core.windows.net':'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2025-03-06T03:02:27Z&st=2025-03-04T19:02:27Z&spr=https&sig=Nh08v2aSh6AhwMY09K0J0isNn%2BqkZcMjezthOEwz9RQ%3D'})

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/goldlayer