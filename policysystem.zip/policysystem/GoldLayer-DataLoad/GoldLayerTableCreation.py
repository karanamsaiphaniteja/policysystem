# Databricks notebook source
# MAGIC %md
# MAGIC Sales By Policy Type and Month:
# MAGIC This table would contain the total sales for each policy type and each month. It would be used to analyze the performance of different policy types over time.

# COMMAND ----------

spark.sql("""create or replace table goldlayer.sales_by_policy_type_and_month(
    policy_type string,
    sale_month string,
    total_premium integer,
    updated_timestamp timestamp
)""")

# COMMAND ----------

# MAGIC %md
# MAGIC Claims By Policy Type and Status:
# MAGIC This table would contain the number and amount of claims by policy type and claim status. It would be used to monitor the claims process and identify any trends or issues.

# COMMAND ----------

spark.sql("""create or replace table goldlayer.claims_by_policy_type_and_status(
    policy_type string,
    claim_status string,
    total_claims integer, 
    total_claim_amount integer,
    updated_timestamp timestamp
)""")

# COMMAND ----------

# MAGIC %md
# MAGIC Analyze the claim data based on the policy type like AVG, MAX, MIN, Count of claim.

# COMMAND ----------

spark.sql("""create or replace table goldlayer.claims_analysis(
    policy_type string,
    claim_status string,
    avg_claim_amount integer,
    max_claim_amount integer,
    min_claim_amount integer,
    total_claims integer, 
    updated_timestamp timestamp
)""")