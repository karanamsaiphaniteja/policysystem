# Databricks notebook source
# MAGIC %sql
# MAGIC create or replace temp view vw_gold_claims_by_policy_type_and_status
# MAGIC as
# MAGIC select
# MAGIC   policy_type,
# MAGIC   claim_status,
# MAGIC   count(*) as total_claims,
# MAGIC   sum(claim_amount) as total_claim_amount
# MAGIC from
# MAGIC   silverlayer.claim c
# MAGIC   JOIN silverlayer.policy p
# MAGIC   ON c.policy_id = p.policy_id
# MAGIC group by
# MAGIC   policy_type,
# MAGIC   claim_status having p.policy_type is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_gold_claims_by_policy_type_and_status

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into goldlayer.claims_by_policy_type_and_status AS T USING vw_gold_claims_by_policy_type_and_status AS S ON T.policy_type = S.policy_type AND T.claim_status = S.claim_status WHEN  MATCHED THEN UPDATE SET T.total_claim_amount = S.total_claim_amount, T.total_claims = S.total_claims, T.updated_timestamp = current_timestamp() WHEN NOT MATCHED THEN INSERT (policy_type, claim_status, total_claims, total_claim_amount, updated_timestamp) VALUES (S.policy_type, S.claim_status, S.total_claims, S.total_claim_amount, current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC Analyze the claim data based on the policy type like AVG, MAX, MIN, Count of claim.

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view vw_gold_claims_analysis as
# MAGIC select
# MAGIC   policy_type,
# MAGIC   AVG(claim_amount) as avg_claim_amount,
# MAGIC   MAX(claim_amount) as max_claim_amount,
# MAGIC   MIN(claim_amount) as min_claim_amount,
# MAGIC   COUNT(DISTINCT claim_id) as total_claims
# MAGIC from
# MAGIC   silverlayer.claim c
# MAGIC   JOIN silverlayer.policy p
# MAGIC   ON c.policy_id = p.policy_id
# MAGIC GROUP BY 
# MAGIC   policy_type HAVING p.policy_type is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into goldlayer.claims_analysis AS T USING vw_gold_claims_analysis AS S ON T.policy_type = S.policy_type WHEN  MATCHED THEN UPDATE SET T.avg_claim_amount = S.avg_claim_amount, T.max_claim_amount = S.max_claim_amount, T.min_claim_amount = S.min_claim_amount, T.total_claims = S.total_claims, T.updated_timestamp = current_timestamp() WHEN NOT MATCHED THEN INSERT (policy_type, avg_claim_amount, max_claim_amount, min_claim_amount, total_claims, updated_timestamp) VALUES (S.policy_type, S.avg_claim_amount, S.max_claim_amount, S.min_claim_amount, S.total_claims, current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from goldlayer.claims_analysis