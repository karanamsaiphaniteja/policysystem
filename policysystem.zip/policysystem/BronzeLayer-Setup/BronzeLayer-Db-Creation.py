# Databricks notebook source
# MAGIC %sql
# MAGIC select current_database()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE brozelayer;

# COMMAND ----------

# MAGIC %sql
# MAGIC use brozelayer