# Databricks notebook source
df = spark.sql("select * from bronzelayer.customer where merge_flag = false and customer_id is not null and gender in ('Male', 'Female') and registration_date > date_of_birth")
display(df)

# COMMAND ----------

df.createOrReplaceTempView("clean_customer")
spark.sql("MERGE INTO silverlayer.customer AS T USING clean_customer AS S ON t.customer_id = s.customer_id WHEN MATCHED THEN UPDATE SET T.first_name = S.first_name, T.last_name = S.last_name, T.email = S.email, T.phone = S.phone, T.country = S.country, T.city = S.city, T.registration_date = S.registration_date, T.date_of_birth = S.date_of_birth, T.gender = S.gender, T.merge_flag = S.merge_flag, T.merged_timestamp = current_timestamp() WHEN NOT MATCHED THEN INSERT (first_name, last_name, email, phone, country, city, registration_date, date_of_birth, gender, merge_flag, merged_timestamp) VALUES (s.first_name, s.last_name, s.email, s.phone, s.country, s.city, s.registration_date, s.date_of_birth, s.gender, s.merge_flag, current_timestamp())")

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE bronzelayer.customer SET merge_flag = true WHERE merge_flag = false