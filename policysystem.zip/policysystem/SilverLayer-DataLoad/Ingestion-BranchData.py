# Databricks notebook source
df = spark.sql("select * from bronzelayer.branch where branch_id is not null and merge_flag = false")
display(df)

# COMMAND ----------

df = spark.sql("select b.branch_id,b.branch_city,upper(trim(b.branch_country)) as branch_country from bronzelayer.branch b where b.branch_id is not null and b.merge_flag = false")
display(df)

# COMMAND ----------

df.createOrReplaceTempView("clean_branch")
spark.sql("MERGE into silverlayer.branch as T using clean_branch AS S ON T.branch_id = S.branch_id WHEN MATCHED THEN UPDATE SET T.branch_city = S.branch_city, T.branch_country = S.branch_country, T.merged_timestamp = current_timestamp() WHEN NOT MATCHED THEN INSERT(branch_id, branch_city, branch_country,merged_timestamp) values (S.branch_id, S.branch_city, S.branch_country,current_timestamp())")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silverlayer.branch

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE bronzelayer.branch SET merge_flag = true WHERE merge_flag = false

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from bronzelayer.branch