# Databricks notebook source
df = spark.sql("select * from bronzelayer.agent where merge_flag = false")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Remove all rows where branch id is null

# COMMAND ----------

df_branch = spark.sql("select * from bronzelayer.branch")
from pyspark.sql.functions import col,length
df_result = spark.sql("select * from bronzelayer.agent inner join bronzelayer.branch on agent.branch_id = branch.branch_id where agent.merge_flag = false and length(agent.agent_phone) = 10")
display(df_result)

# COMMAND ----------

df_test = spark.sql("select branch_id from bronzelayer.agent")
display(df_test)

# COMMAND ----------

df.createOrReplaceTempView("agent_temp")
df_email = spark.sql("select a.agent_id, a.agent_name, a.agent_phone, a.branch_id,a.create_timestamp, regexp_replace(a.agent_email, '', 'admin@azurelib.com') as agent_email from agent_temp a where a.agent_email =''  UNION  select  a.agent_id, a.agent_name, a.agent_phone, a.branch_id,a.create_timestamp, agent_email from agent_temp a where a.agent_email !='' ")

display(df_email)

# COMMAND ----------

df_email.createOrReplaceTempView("clean_agent")

spark.sql(" MERGE INTO silverlayer.agent AS T USING clean_agent AS S ON  t.agent_id = s.agent_id  WHEN MATCHED THEN UPDATE SET t.agent_phone = s.agent_phone, t.agent_email = s.agent_email, t.agent_name = s.agent_name, t.branch_id= s.branch_id, t.create_Timestamp = s.create_TimeStamp, T.merged_timestamp  =  current_timestamp() When not matched then INSert (agent_phone, agent_email , agent_name, branch_id ,create_Timestamp , merged_timestamp, agent_id) values (s.agent_phone, s.agent_email , s.agent_name, s.branch_id ,s.create_Timestamp , current_timestamp(), s.agent_id)")



# COMMAND ----------

spark.sql("update bronzelayer.agent set merge_flag =True WHERE merge_flag = false")
