# Databricks notebook source
df = spark.sql("select p.* from bronzelayer.policy p inner join bronzelayer.customer c on p.customer_id = c.customer_id where p.policy_id is not null  and p.customer_id is not null and p.merge_flag = false and p.premium > 0 and p.coverage_amount > 0 and p.end_date > p.start_date")
display(df)

# COMMAND ----------

df.createOrReplaceTempView("clean_policy")
spark.sql("MERGE into silverlayer.policy t using clean_policy c on t.policy_id = c.policy_id when matched then update set t.policy_type = c.policy_type, t.customer_id = c.customer_id, t.start_date = c.start_date, t.end_date = c.end_date, t.premium = c.premium, t.coverage_amount = c.coverage_amount, t.merged_timestamp = current_timestamp() when not matched then insert (policy_id, policy_type, customer_id, start_date, end_date, premium, coverage_amount, merged_timestamp) values (c.policy_id, c.policy_type, c.customer_id, c.start_date, c.end_date, c.premium, c.coverage_amount, current_timestamp())")

# COMMAND ----------

# MAGIC %sql
# MAGIC update bronzelayer.policy set merge_flag = true where merge_flag = false;
# MAGIC select * from bronzelayer.policy

# COMMAND ----------

