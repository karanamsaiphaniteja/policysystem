# Databricks notebook source
spark.sql("drop table silverlayer.Branch")
agent = spark.sql("create or replace table silverlayer.Branch(branch_id INT, branch_country string, branch_city string, merged_timestamp timestamp)")
agent.write.format("delta").mode("append").saveAsTable("silverlayer.Branch")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silverlayer.branch