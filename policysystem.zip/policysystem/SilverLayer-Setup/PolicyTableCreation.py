# Databricks notebook source
spark.sql("""create table silverlayer.Policy(
policy_id integer,
policy_type string,
customer_id integer,
start_date timestamp,
end_date timestamp,
premium double,
coverage_amount double,
merged_timestamp TIMESTAMP
)""")