# Databricks notebook source
spark.sql("drop table silverlayer.Customer")
# Create or replace the table
spark.sql(
    """
    CREATE OR REPLACE TABLE silverlayer.Customer(
        customer_id INT,
        first_name STRING,
        last_name STRING,
        email STRING,
        phone STRING,
        country STRING,
        city STRING,
        registration_date TIMESTAMP,
        date_of_birth TIMESTAMP,
        gender STRING,
        merge_flag STRING,
        merged_timestamp TIMESTAMP
    )
    """
)




# COMMAND ----------

