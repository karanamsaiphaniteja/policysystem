# Databricks notebook source
# MAGIC %sql
# MAGIC create database silverlayer