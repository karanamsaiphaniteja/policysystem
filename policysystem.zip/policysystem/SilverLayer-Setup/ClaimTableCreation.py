# Databricks notebook source
spark.sql("""
          CREATE OR REPLACE TABLE Silverlayer.Claim (
              claim_id integer,
              policy_id integer,
              date_of_claim DATE,
              claim_amount decimal(18,0),
              claim_status string,
              LastUpdatedTimeStamp timestamp,
              merged_timestamp timestamp)""")