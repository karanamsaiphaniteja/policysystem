# Databricks notebook source
# Create the table in the silverlayer database
spark.sql("drop table silverlayer.Agent")
agent = spark.sql("CREATE or REPLACE TABLE silverlayer.Agent(agent_id INT, agent_name STRING, agent_email STRING, agent_phone STRING, branch_id INT, create_timestamp TIMESTAMP,merged_timestamp TIMESTAMP)")
agent.write.mode("append").saveAsTable("silverlayer.Agent")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silverlayer.agent